
%NOTE: the plots overlap and overwrite each other when this script is run
%all the way through, please view the graphs as they are saved along with
%this script. To construct them from scratch and actually view them, run
%one input file at a time

disp("Cubic Splines:");
disp("input 1:");
cubicDriver("input1spline.txt");
disp("input 2:");
cubicDriver("input2spline.txt");
disp("input 3:");
cubicDriver("input3spline.txt");
disp("input 4:");
cubicDriver("input4spline.txt");
disp("input 5:");
cubicDriver("input5spline.txt");

disp("Least Squares:");
disp("input 1:");
leastSquaresDriver("leastSquaresInput1.txt");
disp("input 2:");
leastSquaresDriver("leastSquaresInput2.txt");
disp("input 3:");
leastSquaresDriver("leastSquaresInput3.txt");
disp("input 4:");
leastSquaresDriver("leastSquaresInput4.txt");
disp("input 5:");
leastSquaresDriver("leastSquaresInput5.txt");

disp("Simpson's method:");
disp("input 1:");
simpsonsDriver("simpsonsInput1.txt");
disp("input 2:");
simpsonsDriver("simpsonsInput2.txt");
disp("input 3:");
simpsonsDriver("simpsonsInput3.txt");
disp("input 4:");
simpsonsDriver("simpsonsInput4.txt");
disp("input 5:");
simpsonsDriver("simpsonsInput5.txt");
%%%%%Simpsons

function simpsonsDriver(fileName)
    [f, a, b, n] = simpsonsInput(fileName);
    ret = simpsons(f, a, b, n);
    disp(ret);
end
function ret = simpsons(f, a, b, n)
    h = (b - a)/n;
    X = a:h:b;
    X = X';
    Y = zeros(n+1,1);
    for i = 1:(n+1)
        Y(i) = f( X(i));
    end
    ret = (h/3) * (Y(1) + 2* sum(Y(2:2:n)) + 4*sum(Y(3:2:n)) + Y(end));
end

%assumes the independent variable is 'x'
function [f, a, b, n] = simpsonsInput(fileName)
    fid = fopen(fileName, 'r');
    fAsStr = fgetl(fid);
    f = inline( fAsStr, 'x');
    a = str2num(fgetl(fid));
    b = str2num(fgetl(fid));
    n = str2num(fgetl(fid));
    
end

%%%%%least Squares
function leastSquaresDriver(fileName)
    [numberOfPoints, degree, points] = leastInput(fileName);
    coeffs = leastSquares(numberOfPoints, degree, points);
    disp(coeffs);
    X = points(:,1);
    hold on
    fplot(constructPoly(coeffs), [(X(1) - 1) (X(end) + 1)] );
    plot(X, points(:,2), '*');
end

function fx = constructPoly(coeffs)
    fx = @(x) coeffs(1);
    
    for i = 2:size(coeffs,1)
        fx = @(x) fx(x)+coeffs(i)*(x).^(i-1);
    end
end

function coeffs = leastSquares(numberOfPoints, degree, points)
    %x summations: xSummations(1) = SUM(xi) xSummations(2) = SUM(xi^2) ...
    %xySummations(1) = SUM(y), xySummations(2) = SUM(xy), xySummations(3) =
    %SUM(x^2*y), ...
    xSummations = zeros(degree * 2, 1);
    xySummations = zeros(degree + 1, 1);
    X = points(:,1);
    Y = points(:,2);
    for i = 1:(degree*2)
        xSummations(i) = sum(X.^i);
    end
    for i = 1:(degree+1)
        xySummations(i) = sum(X.^(i-1) .* Y);
    end
    %matrix construction
    A = zeros(degree+1, degree+1);
    A(1,1) = numberOfPoints;
    A(1,2:end) = xSummations(1:degree);
    for i = 2:degree+1
        A(i,:) = xSummations(i-1:(i-1+degree));
    end
    b = xySummations;
    coeffs = inv(A) * b;
end

function[numberOfPoints, degree, points] = leastInput(fileName)
    fid = fopen(fileName, 'r');
    inp = fscanf(fid, '%f');
    numberOfPoints = inp(1);
    inp(1) = [];
    degree = inp(1);
    inp(1) = [];
    points = [];
    for i = 1:numberOfPoints
        tempPoint = [inp(1) inp(2)];
        points = [points;tempPoint];
        inp(1) = [];
        inp(1) = [];
    end
end

%%%%%cubic splines

function cubicDriver(fileName)
    [n, points] = cubicInput(fileName);
    coefficientArray = cubic(n, points);
    disp("Coefficients:");
    disp(coefficientArray);
    %graph implementation
    X = points(:,1);
    hold on;
    for i = 1:(n-1)
        color = 'r';
        if(rem(i, 2) == 0)
            color = 'b';
        end
        %y = coefficientArray(i, 1) + coefficientArray(i, 2)*(x - X(i)) + coefficientArray(i, 3)*(x - X(i)).^2 + coefficientArray(i, 4)*(x-X(i)).^3;
        fplot(@(x) coefficientArray(i, 1) + coefficientArray(i, 2)*(x - X(i)) + coefficientArray(i, 3)*(x - X(i)).^2 + coefficientArray(i, 4)*(x-X(i)).^3,[X(i) X(i+1)],color );
    end
    hold off;
    grid on;
end

function [A, rowSwaps, b] = gaussian(A, b)
    rowSwaps = 0;
    for i = 1:size(A,1)
        if(A(i,i) == 0)
            rowToSwapIdx = idxToRowSwap(A, i);
            if(rowToSwapIdx < 0)
                rowSwaps = -1;
                break;
            end
            A([i rowToSwapIdx],:) = A([rowToSwapIdx i],:);
            rowSwaps = rowSwaps + 1;
        end
        for j = (i + 1):size(A,1)
            scalar = A(j,i)/A(i,i);
            A(j,:) = A(j,:) - scalar * A(i,:);
            b(j) = b(j) - scalar*b(i);
        end
        
    end
end

%requires upper triangular
function x = backwardsSub(A, b, n)
    x = zeros(n,1);
    x(n) = b(n)/A(n,n);
    for i = (n-1):-1:1
        temp = b(i);
        for j = (i+1):n
            temp = temp - (x(j)*A(i, j));
        end
        x(i) = temp/A(i,i);
    end
end

function ansArray = cubic(n, points)
    %array construction
    A = zeros(n, n);
    A(1,1) = 1;
    A(end) = 1;
    for i = 2:(n-1)
        A(i, i-1) = points(i, 1) - points(i-1, 1);
        A(i, i+1) = points(i+1, 1) - points(i, 1);
        A(i, i) = 2 * (A(i, i-1) + A(i, i+1));
    end
    %vector construction
    x = zeros(n,1);
    for i = 2:(n-1)
        x(i) = (3/A(i, i+1)) * (points(i+1, 2) - points(i, 2)) - (3/A(i, i-1)) * (points(i, 2) - points(i-1, 2));
    end
    %assignment of coefficients
    a = points(:,2);
    [tempArray, ~, x] = gaussian(A, x);
    c = backwardsSub(tempArray, x, n);
    %b and d construction
    h = zeros(n-1,1);
    for i = 1:n-1
        h(i) = points(i+1,1) - points(i,1);
    end
    b = zeros(n-1,1);
    d = zeros(n-1,1);
    for i = 1:(n-1)
        b(i) = (a(i+1) - a(i))/h(i) - ((2 * c(i) + c(i+1))/3)*h(i);
        d(i) = (1/(3*h(i)))*(c(i+1) - c(i));
    end
    a(end) = [];
    c(end) = [];
    ansArray = zeros(n-1, 4);
    ansArray(:,1) = a;
    ansArray(:,2) = b;
    ansArray(:,3) = c;
    ansArray(:,4) = d;
end

function [n, points] = cubicInput(fileName)
    fid = fopen(fileName, 'r');
    inp = fscanf(fid, '%f');
    n = inp(1);
    inp(1) = [];
    points = [];
    for i = 1:n
        tempPoint = [inp(1) inp(2)];
        points = [points;tempPoint];
        inp(1) = [];
        inp(1) = [];
    end
end

        